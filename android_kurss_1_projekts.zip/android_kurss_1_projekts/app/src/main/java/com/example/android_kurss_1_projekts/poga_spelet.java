package com.example.android_kurss_1_projekts;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class poga_spelet extends AppCompatActivity {

    EditText editText1;
    EditText editText2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_poga_spelet);

        editText1 = findViewById(R.id.editTextText);
        editText2 = findViewById(R.id.editTextText2);

        editText1.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    editText1.getText().clear();
                } else if (editText1.getText().toString().isEmpty()) {
                    editText1.setText(R.string.ievadiet_Vardu);
                }
            }
        });

        editText2.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    editText2.getText().clear();
                } else if (editText2.getText().toString().isEmpty()) {
                    editText2.setText(R.string.ievadiet_Vardu);
                }
            }
        });
    }

    public void sumbitSpeletajuVardus(View view) {
        String speletajs1 = editText1.getText().toString();
        String speletajs2 = editText2.getText().toString();

        if (speletajs1.isEmpty() || speletajs1.equals(getString(R.string.ievadiet_Vardu)) || speletajs2.isEmpty() || speletajs2.equals(getString(R.string.ievadiet_Vardu))) {
            Toast.makeText(this, "Lūdzu, ievadiet abus spēlētāju vārdus!", Toast.LENGTH_SHORT).show();
        } else {

            Intent intent = new Intent(this, PalaizSpeli_1v1.class);


            intent.putExtra("player1Name", speletajs1);
            intent.putExtra("player2Name", speletajs2);


            startActivity(intent);
        }
    }

    public void Atgriezties(View view) {
        Toast.makeText(this, "Atgriezties", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}